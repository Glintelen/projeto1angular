import { Component, Output } from '@angular/core';

@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent {

products=["Relógio Ben 10",
   "CD PS1",
    "Cartucho Mario", 
    "LP Roberto Leal",]

    public message!:string;

    receiveMessage(event:string){
      this.message=event;
      
    }
}

import { Component,EventEmitter,Input, Output } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent {
  @Input() products!:string[];
@Output() messageEvent = new EventEmitter<string>();
sendMessage(){
this.messageEvent.emit('passando valor');

}
}
